## Overview

Template files used to create new documents and documents with sample content in: 

* [Jira ONLYOFFICE integration app](https://github.com/ONLYOFFICE/onlyoffice-jira)
* [HumHub ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-humhub)
* [Liferay ONLYOFFICE Connector](https://github.com/ONLYOFFICE/onlyoffice-liferay)
* [Nextcloud ONLYOFFICE integration app](https://github.com/ONLYOFFICE/onlyoffice-nextcloud)
* [Nuxeo ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-nuxeo)
* [Odoo ONLYOFFICE integration app](https://github.com/onlyoffice/onlyoffice-odoo)
* [ONLYOFFICE App for Pipedrive](https://github.com/onlyoffice/onlyoffice-pipedrive)
* [ONLYOFFICE DocSpace App for Zoom](https://github.com/onlyoffice/onlyoffice-docspace-zoom)
* [ONLYOFFICE Docs Integration PHP SDK](https://github.com/ONLYOFFICE/docs-integration-sdk-php/)
* [ownCloud ONLYOFFICE integration app](https://github.com/onlyoffice/onlyoffice-owncloud)
* [Plone ONLYOFFICE integration plugin](https://github.com/onlyoffice/onlyoffice-plone)
