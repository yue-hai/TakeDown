# Change Log

## 2.0.0
- pdf documentType for djvu,  docxf, oform, oxps, pdf, xps
- fb2 additional mime

## 1.1.0
- filling pdf
- conversion formats for txt, csv
- formats for auto conversion

## 1.0.0
- formats for viewing, editing and lossy editing
- formats for conversions
- mime-types of formats
