module.exports = require('@nextcloud/stylelint-config')
