<?php

script('notes', 'notes-main');
style('notes', 'notes');
