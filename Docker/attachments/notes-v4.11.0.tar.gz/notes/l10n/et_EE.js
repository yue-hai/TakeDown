OC.L10N.register(
    "notes",
    {
    "Notes" : "Märkmed",
    "Error" : "Viga",
    "New note" : "Uus märge",
    "Categories" : "Kategooriad",
    "No notes yet" : "Märkmeid veel pole",
    "Share" : "Jaga",
    "Rename" : "Rename",
    "Delete note" : "Kustuta märge",
    "Remove from favorites" : "Eemalda lemmikutest",
    "Add to favorites" : "Lisa lemmikutesse",
    "Use current version" : "Kasuta praegust versiooni",
    "Edit" : "Redigeeri",
    "Preview" : "Eelvaade",
    "Today" : "Täna",
    "Yesterday" : "Eile",
    "Tasks" : "Ülesanded"
},
"nplurals=2; plural=(n != 1);");
