OC.L10N.register(
    "notes",
    {
    "Notes" : "Նոթեր",
    "Error" : "Սխալ",
    "New note" : "Նոր նոթ",
    "No notes yet" : "առայժմ գրառում չկա",
    "Share" : "Կիսվել",
    "Rename" : "Rename",
    "Delete note" : "Ջնջել նոթը",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "մշակել",
    "Today" : "այսօր",
    "Yesterday" : "երեկ",
    "This week" : "այս շաբաթ",
    "This month" : "այս ամիս"
},
"nplurals=2; plural=(n != 1);");
