OC.L10N.register(
    "notes",
    {
    "Notes" : "Notes",
    "Error" : "ایرر",
    "Share" : "تقسیم",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "تدوین کریں",
    "Today" : "آج",
    "Tasks" : "کام"
},
"nplurals=2; plural=(n != 1);");
