OC.L10N.register(
    "notes",
    {
    "Notes" : "Catatan",
    "Error" : "Kesalahan",
    "New note" : "Catatan baru",
    "All notes" : "Semua catatan",
    "Categories" : "Kategori",
    "No notes yet" : "Belum ada catatan",
    "Share" : "Bagikan",
    "Delete note" : "Hapus catatan",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Tambah ke favorit",
    "Edit" : "Sunting",
    "Preview" : "Pratinjau",
    "Today" : "Hari ini",
    "Yesterday" : "Kemarin",
    "This week" : "Pekan ini",
    "This month" : "Bulan ini",
    "Tasks" : "Tugas",
    "Nextcloud, a safe home for all your data" : "Nextcloud, rumah yang aman untuk semua data Anda"
},
"nplurals=1; plural=0;");
