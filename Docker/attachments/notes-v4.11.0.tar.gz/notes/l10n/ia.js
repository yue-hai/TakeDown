OC.L10N.register(
    "notes",
    {
    "Notes" : "Notas",
    "Error" : "Error",
    "New note" : "Nove nota",
    "No notes yet" : "Nulle notas ancora",
    "Share" : "Compartir",
    "Rename" : "Rename",
    "Delete note" : "Dele nota",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Modificar",
    "Preview" : "Previsualisar",
    "Today" : "Hodie",
    "Yesterday" : "Heri",
    "This week" : "Iste septimana",
    "This month" : "Iste mense"
},
"nplurals=2; plural=(n != 1);");
