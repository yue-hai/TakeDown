OC.L10N.register(
    "notes",
    {
    "Notes" : "Qeydlər",
    "Error" : "Səhv",
    "New note" : "Yeni qeyd",
    "Share" : "Paylaş",
    "Rename" : "Rename",
    "Delete note" : "Qeydi sil",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Dəyişiklik et",
    "Today" : "Bu gün",
    "Yesterday" : "Dünən",
    "Tasks" : "Tapşırıqlar"
},
"nplurals=2; plural=(n != 1);");
