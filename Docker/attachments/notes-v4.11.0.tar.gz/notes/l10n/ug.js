OC.L10N.register(
    "notes",
    {
    "Notes" : "ئىزاھاتلار",
    "Error" : "خاتالىق",
    "Share" : "ھەمبەھىر",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "تەھرىر",
    "Today" : "بۈگۈن",
    "Tasks" : "ۋەزىپەلەر"
},
"nplurals=2; plural=(n != 1);");
