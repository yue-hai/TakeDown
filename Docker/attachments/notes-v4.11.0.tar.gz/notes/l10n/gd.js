OC.L10N.register(
    "notes",
    {
    "Notes" : "Nòtaichean",
    "Error" : "Mearachd",
    "New note" : "Nòta ùr",
    "Display mode for notes" : "Modh sealladh nan nòtaichean",
    "All notes" : "A h-uile nòta",
    "Add to favorites" : "Cuir ris na h-annsachdan",
    "Edit" : "Deasaich",
    "Preview" : "Ro-sheall",
    "Today" : "An-diugh",
    "Yesterday" : "An-dè",
    "This week" : "An t-seachdain seo",
    "Last week" : "An t-seachdain seo chaidh",
    "This month" : "Am mìos seo",
    "Last month" : "Am mìos seo chaidh",
    "Uncategorized" : "Gun seòrsachadh"
},
"nplurals=4; plural=(n==1 || n==11) ? 0 : (n==2 || n==12) ? 1 : (n > 2 && n < 20) ? 2 : 3;");
