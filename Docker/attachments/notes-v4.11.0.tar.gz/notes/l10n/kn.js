OC.L10N.register(
    "notes",
    {
    "Notes" : "Notes",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Share" : "﻿ಹಂಚಿಕೊಳ್ಳಿ",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "ಸಂಪಾದಿಸು",
    "Today" : "Today"
},
"nplurals=2; plural=(n > 1);");
