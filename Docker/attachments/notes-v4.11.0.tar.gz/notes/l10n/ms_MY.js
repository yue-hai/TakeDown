OC.L10N.register(
    "notes",
    {
    "Notes" : "Nota",
    "Error" : "Ralat",
    "New note" : "Note baharu",
    "Share" : "Kongsi",
    "Rename" : "Rename",
    "Delete note" : "Hapus nota",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Sunting",
    "Today" : "Hari ini",
    "Yesterday" : "Semalam"
},
"nplurals=1; plural=0;");
