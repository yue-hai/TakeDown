OC.L10N.register(
    "notes",
    {
    "Notes" : "සටහන්",
    "Error" : "දෝෂය",
    "New note" : "නව සටහන",
    "All notes" : "සියලුම සටහන්",
    "No notes yet" : "තවම සටහන් නැත",
    "Rename" : "නැවත නම් කරන්න",
    "Edit" : "සංස්කරණය",
    "Preview" : "පෙරදසුන",
    "Loading …" : "පූරණය වෙමින් …",
    "Today" : "අද",
    "Yesterday" : "ඊයේ",
    "This week" : "මෙම සතිය",
    "Last week" : "පසුගිය සතිය",
    "This month" : "මෙම මාසය",
    "Last month" : "පසුගිය මාසය",
    "Tasks" : "කාර්යයන්"
},
"nplurals=2; plural=(n != 1);");
