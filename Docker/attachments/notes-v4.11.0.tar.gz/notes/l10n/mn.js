OC.L10N.register(
    "notes",
    {
    "Notes" : "Тэмдэглэл",
    "Error" : "Алдаа",
    "New note" : "Шинэ тэмдэглэл",
    "All notes" : "Бүх тэмдэг",
    "Categories" : "төрөл",
    "No notes yet" : "шинэ тэмдэглэл алга",
    "Share" : "Түгээх",
    "Rename" : "Нэр солих",
    "Delete note" : "Тэмдэглэл устгах",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "засварлах",
    "Preview" : "шалгах",
    "Loading …" : "Уншиж байна...",
    "Today" : "өнөөдөр",
    "Yesterday" : "өчигдөр",
    "This week" : "7 хоног",
    "This month" : "1 сар"
},
"nplurals=2; plural=(n != 1);");
