OC.L10N.register(
    "notes",
    {
    "Notes" : "নোট",
    "Error" : "সমস্যা",
    "New note" : "নতুন নোট",
    "Share" : "ভাগাভাগি কর",
    "Rename" : "Rename",
    "Delete note" : "নোট মোছ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "সম্পাদনা",
    "Today" : "আজ",
    "Yesterday" : "গতকাল",
    "Tasks" : "কর্ম"
},
"nplurals=2; plural=(n != 1);");
