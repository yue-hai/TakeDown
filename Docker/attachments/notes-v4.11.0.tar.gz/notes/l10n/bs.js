OC.L10N.register(
    "notes",
    {
    "Notes" : "Notes",
    "Error" : "Greška",
    "Share" : "Podjeli",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Izmjeni",
    "Today" : "Danas",
    "Yesterday" : "Jučer",
    "Tasks" : "Zadaci"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
