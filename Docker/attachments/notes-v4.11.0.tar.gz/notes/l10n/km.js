OC.L10N.register(
    "notes",
    {
    "Notes" : "កំណត់​ចំណាំ",
    "Error" : "កំហុស",
    "New note" : "កំណត់​ចំណាំ​ថ្មី",
    "Share" : "ចែក​រំលែក",
    "Rename" : "Rename",
    "Delete note" : "លុប​កំណត់​ចំណាំ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "កែប្រែ",
    "Today" : "ថ្ងៃ​នេះ",
    "Tasks" : "ភារកិច្ច"
},
"nplurals=1; plural=0;");
