OC.L10N.register(
    "notes",
    {
    "Notes" : "குறிப்புகள்",
    "Error" : "வழு",
    "Share" : "பகிர்வு",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "தொகுக்க",
    "Today" : "இன்று",
    "Yesterday" : "நேற்று",
    "Tasks" : "கடமைகள்"
},
"nplurals=2; plural=(n != 1);");
