OC.L10N.register(
    "notes",
    {
    "Notes" : "Notat",
    "Error" : "Feil",
    "New note" : "Nytt notat",
    "Share" : "Del",
    "Rename" : "Gje nytt namn",
    "Delete note" : "Slett notat",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Endra",
    "Today" : "I dag",
    "Yesterday" : "i går",
    "Tasks" : "Oppgåver"
},
"nplurals=2; plural=(n != 1);");
