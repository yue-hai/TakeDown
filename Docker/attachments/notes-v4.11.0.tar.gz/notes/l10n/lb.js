OC.L10N.register(
    "notes",
    {
    "Notes" : "Notizen",
    "Error" : "Fehler",
    "Share" : "Deelen",
    "Rename" : "Rename",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Änneren",
    "Loading …" : "Loading …",
    "Today" : "Haut",
    "Yesterday" : "Gëschter",
    "Tasks" : "Tâchen"
},
"nplurals=2; plural=(n != 1);");
