OC.L10N.register(
    "notes",
    {
    "Notes" : "شسیب",
    "Error" : "شسیب",
    "Share" : "شریکول",
    "Remove from favorites" : "له نښو ويستل",
    "Add to favorites" : "په نښه کول",
    "Today" : "نن",
    "Yesterday" : "پرون"
},
"nplurals=2; plural=(n != 1);");
