OC.L10N.register(
    "notes",
    {
    "Error" : "ຜິດພາດ",
    "Share" : "ເເບ່ງປັນ",
    "Rename" : "ປ່ຽນຊື່",
    "Remove from favorites" : "ຍ້າຍຈາກລາຍການທີ່ມັກ",
    "Add to favorites" : "ເພີ່ມລາຍການທີ່ມັກ",
    "Edit" : "ແກ້ໄຂ",
    "Loading …" : "ກຳລັງໂຫຼດ",
    "Today" : "ມື້ນີ້",
    "Yesterday" : "ມື້ວານນີ້",
    "This week" : "ທິດນີ້"
},
"nplurals=1; plural=0;");
