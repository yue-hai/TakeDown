OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Не можете да отворите папка",
    "An internal server error occurred." : "Се случи внатрешна грешка.",
    "This file is too big to be opened. Please download the file instead." : "Датотеката е премногу голема за да се отвори. Преземете ја датотеката и отворете ја.",
    "Cannot read the file." : "Неможе да се прочита датотеката.",
    "File not found." : "Датотеката не е пронајдена.",
    "The file is locked." : "Датотеката е заклучена.",
    "Could not write to file." : "Не може да се запише во датотеката",
    "Saving..." : "Зачувува ...",
    "Auto" : "Автоматски",
    "Dark" : "Темна",
    "Yes" : "Да",
    "No" : "Не",
    "Language" : "Јазик",
    "Save" : "Зачувај"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
