OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Stoor tans…",
    "Dark" : "Donker",
    "Yes" : "Ja",
    "No" : "Nee",
    "Language" : "Taal",
    "Save" : "Bewaar"
},
"nplurals=2; plural=(n != 1);");
