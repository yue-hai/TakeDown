OC.L10N.register(
    "drawio",
    {
    "Dark" : "Ubrik",
    "Yes" : "Oui",
    "No" : "Uhu",
    "Save" : "Sekles"
},
"nplurals=2; plural=(n != 1);");
