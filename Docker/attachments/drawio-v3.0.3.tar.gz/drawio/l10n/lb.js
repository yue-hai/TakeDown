OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Speicheren...",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Sprooch",
    "Save" : "Späicheren"
},
"nplurals=2; plural=(n != 1);");
