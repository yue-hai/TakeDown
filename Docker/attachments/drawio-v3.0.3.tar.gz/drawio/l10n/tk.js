OC.L10N.register(
    "drawio",
    {
    "Dark" : "Garaňky",
    "Yes" : "Hawa",
    "No" : "Ýok",
    "Save" : "Saklamak"
},
"nplurals=2; plural=(n != 1);");
