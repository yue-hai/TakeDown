OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Ju nuk mund të hapni një dosje",
    "An internal server error occurred." : "Ndodhi një gabim i brendshëm shërbyesi.",
    "This file is too big to be opened. Please download the file instead." : "Kjo kartelë është shumë e madhe për hapje. Ju lutemi, në vend të kësaj, shkarkojeni.",
    "Cannot read the file." : "S’lexohet dot kartela.",
    "The file is locked." : "Kartela është e kyçur.",
    "You can not write to a folder" : "Ju s'mund të shkruani tek një dosje ",
    "Insufficient permissions" : "Leje të pamjaftueshme",
    "Saving..." : "Duke ruajtur...",
    "Dark" : "E errët",
    "Yes" : "Yes",
    "No" : "Jo",
    "Language" : "Gjuha",
    "Save" : "Ruaj"
},
"nplurals=2; plural=(n != 1);");
