OC.L10N.register(
    "drawio",
    {
    "Dark" : "ມືດ",
    "Yes" : "ແມ່ນແລ້ວ",
    "No" : "ບໍ່",
    "Save" : "ບັນທຶກ"
},
"nplurals=1; plural=0;");
