OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Saglabā...",
    "Auto" : "Automātiski",
    "Dark" : "Tumšs",
    "Yes" : "Jā",
    "No" : "Nē",
    "Language" : "Valoda",
    "Save" : "Saglabāt"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
