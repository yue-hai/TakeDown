OC.L10N.register(
    "drawio",
    {
    "Saving..." : "ساقلاۋاتىدۇ…",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "تىل",
    "Save" : "ساقلا"
},
"nplurals=2; plural=(n != 1);");
