OC.L10N.register(
    "drawio",
    {
    "An internal server error occurred." : "เกิดข้อผิดพลาดภายในเซิร์ฟเวอร์",
    "This file is too big to be opened. Please download the file instead." : "เปิดไฟล์นี้ไม่ได้ เพราะมีขนาดใหญ่เกินไป กรุณาดาวน์โหลดไฟล์แทน",
    "Cannot read the file." : "ไม่สามารถอ่านไฟล์",
    "The file is locked." : "ไฟล์ถูกล็อก",
    "Insufficient permissions" : "สิทธิ์ไม่เพียงพอ",
    "Saving..." : "กำลังบันทึกข้อมูล...",
    "Dark" : "เข้ม",
    "Yes" : "ใช่",
    "No" : "ไม่",
    "Language" : "ภาษา",
    "Save" : "บันทึก"
},
"nplurals=1; plural=0;");
