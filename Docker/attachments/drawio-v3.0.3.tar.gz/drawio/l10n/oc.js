OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Podètz pas dobrir un dossièr",
    "An internal server error occurred." : "Una error intèrna del servidor s'es produsida.",
    "This file is too big to be opened. Please download the file instead." : "Aqueste fichièr es tròp voluminós per èsser dobèrt. Telecargatz-lo, puslèu.",
    "Cannot read the file." : "Impossible de legir lo fichièr.",
    "File not found." : "Fichièr pas trobat",
    "The file is locked." : "Lo fichièr es verrolhat.",
    "Insufficient permissions" : "Permissions insufisentas",
    "Saving..." : "Enregistrament...",
    "Dark" : "Escur",
    "Yes" : "Òc",
    "No" : "Non",
    "Language" : "Lenga",
    "Save" : "Enregistrar"
},
"nplurals=2; plural=(n > 1);");
