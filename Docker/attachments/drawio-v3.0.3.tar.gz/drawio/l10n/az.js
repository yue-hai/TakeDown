OC.L10N.register(
    "drawio",
    {
    "Insufficient permissions" : "Qeyri kafi yetkilər",
    "Saving..." : "Saxlama...",
    "Dark" : "Qaranlıq",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Dil",
    "Save" : "Saxla"
},
"nplurals=2; plural=(n != 1);");
