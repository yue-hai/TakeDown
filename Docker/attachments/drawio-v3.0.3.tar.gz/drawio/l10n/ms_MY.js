OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Sedang menyimpan...",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Bahasa",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
