OC.L10N.register(
    "drawio",
    {
    "An internal server error occurred." : "Սերվերի ներքին սխալ։",
    "This file is too big to be opened. Please download the file instead." : "Ֆայլը չափից ավելի մեծ է բացելու համար։ Փոխարենը ներբեռնիր խնդրում եմ:",
    "Cannot read the file." : "Չկարողացա կարդալ ֆայլը։",
    "The file is locked." : "Ֆայլը կողպած է։",
    "Saving..." : "Պահում եմ...",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Լեզու",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
