OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Salveguardante...",
    "Yes" : "Si",
    "No" : "No",
    "Language" : "Lingua",
    "Save" : "Salveguardar"
},
"nplurals=2; plural=(n != 1);");
