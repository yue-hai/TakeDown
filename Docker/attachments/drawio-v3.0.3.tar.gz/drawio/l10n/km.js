OC.L10N.register(
    "drawio",
    {
    "Saving..." : "កំពុង​រក្សាទុក",
    "Dark" : "ងងឹត",
    "Yes" : "បាទ ឬចាស",
    "No" : "ទេ",
    "Language" : "ភាសា",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
