OC.L10N.register(
    "drawio",
    {
    "An internal server error occurred." : "An internal server error occurred.",
    "This file is too big to be opened. Please download the file instead." : "This file is too big to be opened. Please download the file instead.",
    "Cannot read the file." : "Cannot read the file.",
    "The file is locked." : "The file is locked.",
    "Could not write to file." : "Could not write to file.",
    "Auto" : "Auto",
    "Dark" : "Dark",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Language",
    "Save" : "Save"
},
"nplurals=2; plural=(n!=1);");
