OC.L10N.register(
    "drawio",
    {
    "File not found." : "ගොනුව හමු නොවිණි.",
    "Dark" : "අඳුරු",
    "Yes" : "ඔව්",
    "No" : "නැහැ",
    "Language" : "භාෂාව",
    "Save" : "සුරකින්න"
},
"nplurals=2; plural=(n != 1);");
