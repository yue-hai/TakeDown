OC.L10N.register(
    "drawio",
    {
    "Yes" : "هو",
    "No" : "نه",
    "Save" : "ساتل"
},
"nplurals=2; plural=(n != 1);");
