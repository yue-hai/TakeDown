OC.L10N.register(
    "drawio",
    {
    "Yes" : "Si",
    "No" : "No",
    "Language" : "Luenga"
},
"nplurals=2; plural=(n != 1);");
