OC.L10N.register(
    "drawio",
    {
    "An internal server error occurred." : "Đã xảy ra lỗi máy chủ nội bộ.",
    "This file is too big to be opened. Please download the file instead." : "Tệp này quá lớn để mở. Vui lòng tải xuống thay vì mở trực tiếp.",
    "Cannot read the file." : "Không thể đọc thư mục",
    "File not found." : "Không tìm thấy tệp tin.",
    "The file is locked." : "Thư mục đã khóa",
    "Could not write to file." : "Không thể ghi vào tệp.",
    "Insufficient permissions" : "Không đủ quyền",
    "Saving..." : "Đang lưu...",
    "Auto" : "Tự động",
    "Dark" : "Tối",
    "Yes" : "Có",
    "No" : "Không",
    "Language" : "Ngôn ngữ",
    "Save" : "Lưu"
},
"nplurals=1; plural=0;");
