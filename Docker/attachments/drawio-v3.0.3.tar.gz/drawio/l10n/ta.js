OC.L10N.register(
    "drawio",
    {
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "மொழி",
    "Save" : "சேமிக்க "
},
"nplurals=2; plural=(n != 1);");
