OC.L10N.register(
    "drawio",
    {
    "Dark" : "хар",
    "Yes" : "Тийм",
    "No" : "Үгүй",
    "Language" : "Хэл",
    "Save" : "Хадгалах"
},
"nplurals=2; plural=(n != 1);");
