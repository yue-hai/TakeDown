OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Ne povas malfermi dosierujo",
    "An internal server error occurred." : "Ena servileraro okazis.",
    "This file is too big to be opened. Please download the file instead." : "La dosiero tro grandas por malfermi. Bonvolu elŝuti la dosieron anstataŭe.",
    "Cannot read the file." : "Ne legeblas la dosiero.",
    "The file is locked." : "La dosiero estas ŝlosa.",
    "You can not write to a folder" : "Ne povas skribi al dosierujo",
    "Could not write to file." : "Ne povis skribi al dosiero.",
    "Insufficient permissions" : "Nesufiĉaj permesoj",
    "Saving..." : "Konservado...",
    "Auto" : "Aŭtomate",
    "Dark" : "Malluma",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Lingvo",
    "Save" : "Konservi"
},
"nplurals=2; plural=(n != 1);");
