OC.L10N.register(
    "drawio",
    {
    "Saving..." : "محفوظ ھو رہا ہے ...",
    "Yes" : "Yes",
    "No" : "No",
    "Save" : "حفظ"
},
"nplurals=2; plural=(n != 1);");
