OC.L10N.register(
    "drawio",
    {
    "An internal server error occurred." : "Det oppstod ein intern tenarfeil.",
    "This file is too big to be opened. Please download the file instead." : "Fila er for stor for å opnast. Ver venleg å laste ned fila i staden for.",
    "Cannot read the file." : "Kan ikkje lesa fila.",
    "The file is locked." : "Fila er låst.",
    "Saving..." : "Lagrar …",
    "Yes" : "Ja",
    "No" : "Nei",
    "Language" : "Språk",
    "Save" : "Lagre"
},
"nplurals=2; plural=(n != 1);");
