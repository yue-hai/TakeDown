OC.L10N.register(
    "drawio",
    {
    "Saving..." : "Saqlanmoqda...",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "Language",
    "Save" : "Save"
},
"nplurals=1; plural=0;");
