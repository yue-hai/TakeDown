OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Sa ei saa avada kausta",
    "An internal server error occurred." : "Tekkis sisemine serveri tõrge.",
    "This file is too big to be opened. Please download the file instead." : "See fail on avamiseks liiga suur. Palun lae allla.",
    "Cannot read the file." : "Faili lugemine ebaõnnestus.",
    "File not found." : "Faili ei leitud",
    "The file is locked." : "Fail on lukus.",
    "You can not write to a folder" : "Sa ei saa kirjutada kausta",
    "Insufficient permissions" : "Pole piisavalt õiguseid",
    "Saving..." : "Salvestamine...",
    "Dark" : "Hele",
    "Yes" : "Jah",
    "No" : "Ei",
    "Language" : "Keel",
    "Save" : "Salvesta"
},
"nplurals=2; plural=(n != 1);");
