OC.L10N.register(
    "drawio",
    {
    "Saving..." : "সংরক্ষণ করা হচ্ছে..",
    "Dark" : "গাঢ়",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "ভাষা",
    "Save" : "সংরক্ষণ"
},
"nplurals=2; plural=(n != 1);");
