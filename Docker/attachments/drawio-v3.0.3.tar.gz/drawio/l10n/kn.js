OC.L10N.register(
    "drawio",
    {
    "Saving..." : "﻿ಉಳಿಸಲಾಗುತ್ತಿದೆ ...",
    "Yes" : "Yes",
    "No" : "No",
    "Language" : "﻿ಭಾಷೆ",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
