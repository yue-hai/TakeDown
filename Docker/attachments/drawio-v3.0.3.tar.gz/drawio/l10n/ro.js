OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Nu se poate deschide un folder",
    "An internal server error occurred." : "A apărut o eroare internp a serverului.",
    "This file is too big to be opened. Please download the file instead." : "Fișierul este prea mare pentru a fi deschis. Descarcă-l în schimb.",
    "Cannot read the file." : "Fișierul nu poate fi citit.",
    "The file is locked." : "Fișierul este blocat.",
    "You can not write to a folder" : "Nu se poate scrie într-un folder",
    "Insufficient permissions" : "Permisiuni insuficiente",
    "Saving..." : "Se salvează...",
    "Auto" : "Auto",
    "Dark" : "Întunecat",
    "Yes" : "a",
    "No" : "Nu",
    "Language" : "Limba",
    "Save" : "Salvează"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
