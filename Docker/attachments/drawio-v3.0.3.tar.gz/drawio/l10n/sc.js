OC.L10N.register(
    "drawio",
    {
    "You can not open a folder" : "Non podes abèrrere una cartella",
    "An internal server error occurred." : "Ddoe at àpidu un'errore internu de su serbidore.",
    "This file is too big to be opened. Please download the file instead." : "Custu archìviu est tropu mannu pro dd'abèrrere. Mancari iscàrriga s'archìviu.",
    "Cannot read the file." : "Impossìbile a lèghere s'archìviu.",
    "File not found." : "Archìviu no agatadu.",
    "The file is locked." : "S'archìviu est blocadu.",
    "You can not write to a folder" : "Non podes iscrìere in una cartella",
    "Could not write to file." : "No at fatu a iscrìere in s'archìviu.",
    "Insufficient permissions" : "Permissos non sufitzientes",
    "Saving..." : "Sarvende...",
    "Auto" : "Auto",
    "Dark" : "Iscuru",
    "Yes" : "Si",
    "No" : "No",
    "Language" : "Limba",
    "Save" : "Sarva"
},
"nplurals=2; plural=(n != 1);");
